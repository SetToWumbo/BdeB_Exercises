import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Player {
    public Jeton jeton;
    public String nom;

    public static void afficherJeu(Jeton[][] planJeu) {

        for (int row = 0; row < planJeu.length; row++) {

            for (int col = 0; col < planJeu[0].length; col++) {
                System.out.print("|");
                System.out.print(planJeu[row][col].type);
                System.out.print("|");
            }
            System.out.println();
        }

        System.out.println();
    }

    public static Player remplirTab(int[] pos, Jeton[][] planJeu) {
        int H = 0;
        int V = 0;
        int D1 = 0;
        int D2 = 0;
        Jeton jeton = Jeton.ROUGE;
        int y;
        int x;
        int y2;
        for (int offset = -3; offset <= 3; offset++) {
            x = pos[1] + offset;
            y = pos[0] + offset;
            y2 = pos[0] - offset;

            if (y >= 0 && y < planJeu.length) {
                // axe vertical
                planJeu[y][pos[1]] = jeton;

            }
            if (x >= 0 && x < planJeu[pos[0]].length) {
                // axe horizontal
                planJeu[pos[0]][x] = jeton;

            }
            if (x >= 0 && x < planJeu[pos[0]].length) {
                // Diagonale gauche droite vers le bas
                if (y >= 0 && y < planJeu.length) {
                    planJeu[y][x] = jeton;

                }
                if (y2 >= 0 && y2 < planJeu.length) {
                    // Diagonale gauche droite vers le haut
                    planJeu[y2][x] = jeton;

                }
            }
        }
        return null;
    }

    Player(Jeton jeton) {
        this.jeton = jeton;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    /**
     * Methode prends un tableau de Jetons et la position du jeton qui vient d'être joué,
     * vérifie les 4 axes autour du jeton avec un offset maximum de + ou - 3, comptabilise le nombre de jetons consécutifs
     * qui correspondent au notre et retourne l'instance du joueur s'il a gagné, sinon retourne null.
     * <p>
     * C'est un laid, mais ça fonctionne!
     *
     * @param pos     position du jeton qui a été joué (pos[0] = position verticale, pos[1] = position horizontale)
     * @param planJeu plan du jeu Connect 4 dans lequel le jeton a été placé
     */
    public Player joueurGagnant(int[] pos, Jeton[][] planJeu) {
        int H = 0;
        int V = 0;
        int D1 = 0;
        int D2 = 0;

        int y;
        int x;
        int y2;
        for (int offset = -3; offset <= 3; offset++) {
            x = pos[1] + offset;
            y = pos[0] + offset;
            y2 = pos[0] - offset;

            if (y >= 0 && y < planJeu.length) {
                // axe vertical
                if (planJeu[y][pos[1]] == jeton) {
                    V++;
//                    System.out.println("Jetons consecutifs V: " + V);
                    if (V == 4) {
//                        System.out.println("Gagne!!");
                        return this;
                    }
                } else {
                    V = 0;
                }
            }
            if (x >= 0 && x < planJeu[pos[0]].length) {
                // axe horizontal
                if (planJeu[pos[0]][x] == jeton) {
                    H++;
//                    System.out.println("Jetons consecutifs H: " + H);
                    if (H == 4) {
//                        System.out.println("Gagne!!");
                        return this;
                    }
                } else {
                    H = 0;
                }
            }
            if (x >= 0 && x < planJeu[pos[0]].length) {
                if (y >= 0 && y < planJeu.length) {
                    if (planJeu[y][x] == jeton) {
                        D1++;
//                        System.out.println("Jetons consecutifs D1: " + D1);
                        if (D1 == 4) {
//                            System.out.println("Gagne!!");
                            return this;
                        }
                    } else {
                        D1 = 0;

                    }
                }
                if (y2 >= 0 && y2 < planJeu.length) {
                    if (planJeu[y2][x] == jeton) {
                        D2++;
//                        System.out.println("Jetons consecutifs D2: " + D2);
                        if (D2 == 4) {
//                            System.out.println("Gagne!!");
                            return this;
                        }
                    } else {
                        D2 = 0;
                    }
                }
            }
        }
        return null;
    }

    public Jeton getJeton(int[] pos, Jeton[][] planJeu) {
        return planJeu[pos[0]][pos[1]];
    }
}

